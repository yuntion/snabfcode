package pass3_test
import (
"testing"
m0 "snabf.local/compiler/build/pass1-native-clean.W2pb5Lzm/run.lA2p4ZDE/pass3/reuse64/no_trunc"
m1 "snabf.local/compiler/build/pass1-native-clean.W2pb5Lzm/run.lA2p4ZDE/pass3/reuse64/joint"
m2 "snabf.local/compiler/build/pass1-native-clean.W2pb5Lzm/run.lA2p4ZDE/pass3/reuse64/matched_exact"
m3 "snabf.local/compiler/build/pass1-native-clean.W2pb5Lzm/run.lA2p4ZDE/pass3/residual/no_trunc"
m4 "snabf.local/compiler/build/pass1-native-clean.W2pb5Lzm/run.lA2p4ZDE/pass3/residual/joint"
m5 "snabf.local/compiler/build/pass1-native-clean.W2pb5Lzm/run.lA2p4ZDE/pass3/residual/matched_exact"
)
func Test_reuse64(t *testing.T){experiment(t,"../reuse64",[]program{{"no_trunc",m0.Linear_silu_linear__configure,m0.Linear_silu_linear__preprocessing,m0.Linear_silu_linear__preprocessed,m0.Linear_silu_linear__encrypt__arg0,m0.Linear_silu_linear__decrypt__result0},{"joint",m1.Linear_silu_linear__configure,m1.Linear_silu_linear__preprocessing,m1.Linear_silu_linear__preprocessed,m1.Linear_silu_linear__encrypt__arg0,m1.Linear_silu_linear__decrypt__result0},{"matched_exact",m2.Linear_silu_linear__configure,m2.Linear_silu_linear__preprocessing,m2.Linear_silu_linear__preprocessed,m2.Linear_silu_linear__encrypt__arg0,m2.Linear_silu_linear__decrypt__result0}})}
func Test_residual(t *testing.T){experiment(t,"../residual",[]program{{"no_trunc",m3.Linear_silu_linear__configure,m3.Linear_silu_linear__preprocessing,m3.Linear_silu_linear__preprocessed,m3.Linear_silu_linear__encrypt__arg0,m3.Linear_silu_linear__decrypt__result0},{"joint",m4.Linear_silu_linear__configure,m4.Linear_silu_linear__preprocessing,m4.Linear_silu_linear__preprocessed,m4.Linear_silu_linear__encrypt__arg0,m4.Linear_silu_linear__decrypt__result0},{"matched_exact",m5.Linear_silu_linear__configure,m5.Linear_silu_linear__preprocessing,m5.Linear_silu_linear__preprocessed,m5.Linear_silu_linear__encrypt__arg0,m5.Linear_silu_linear__decrypt__result0}})}
