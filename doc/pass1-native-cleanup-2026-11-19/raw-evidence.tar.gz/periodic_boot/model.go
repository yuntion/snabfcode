package periodicboot

import (
	"github.com/tuneinsight/lattigo/v6/core/rlwe"
	"github.com/tuneinsight/lattigo/v6/schemes/ckks"
	"github.com/tuneinsight/lattigo/v6/utils"
	bootstrapping "snabf.local/compiler/src/backend/ringswitch"
)

func Bootstrap(bootstrapping_evaluator *bootstrapping.Evaluator, _ *ckks.Evaluator, _ ckks.Parameters, _ *ckks.Encoder, ct *rlwe.Ciphertext) *rlwe.Ciphertext {
	ct1, err0 := bootstrapping_evaluator.Bootstrap(ct.CopyNew())
	if err0 != nil {
		panic(err0)
	}
	return ct1
}
func Bootstrap__configure() (*bootstrapping.Evaluator, *ckks.Evaluator, ckks.Parameters, *ckks.Encoder, *rlwe.Encryptor, *rlwe.Decryptor) {
	param, err1 := ckks.NewParametersFromLiteral(ckks.ParametersLiteral{
		LogN:            16,
		Q:               []uint64{1099512938497, 2148794369, 2150760449, 2150891521, 2151677953},
		P:               []uint64{72057594038321153, 72057594040680449},
		LogDefaultScale: 31,
	})
	if err1 != nil {
		panic(err1)
	}
	encoder := ckks.NewEncoder(param)
	kgen := rlwe.NewKeyGenerator(param)
	sk, pk := kgen.GenKeyPairNew()
	encryptor := rlwe.NewEncryptor(param, pk)
	decryptor := rlwe.NewDecryptor(param, sk)
	bootstrapping_param, err7 := bootstrapping.NewParametersFromLiteral(param, bootstrapping.ParametersLiteral{
		LogN: utils.Pointy(16),
	}, bootstrapping.Plan{Source: 65536,
		Target: 32768, Period: 64, Level: 1, LogScale: 31, Q: []uint64{0x10000140001,
			0x80140001, 0x80320001, 0x80340001, 0x80400001},
		P: []uint64{0x100000000060001, 0x1000000002a0001}},
	)
	if err7 != nil {
		panic(err7)
	}
	bootstrapping_eval_keys, _, err8 := bootstrapping_param.GenEvaluationKeys(sk)
	if err8 != nil {
		panic(err8)
	}
	bootstrapping_evaluator, err10 := bootstrapping.NewEvaluator(bootstrapping_param, bootstrapping_eval_keys)
	if err10 != nil {
		panic(err10)
	}
	evaluator := ckks.NewEvaluator(param, nil)
	return bootstrapping_evaluator, evaluator, param, encoder, encryptor, decryptor
}
