!bootstrapping_eval_keys = !lattigo.ckks.bootstrapping_eval_keys
!bootstrapping_evaluator = !lattigo.ckks.bootstrapping_evaluator
!bootstrapping_param = !lattigo.ckks.bootstrapping_parameter
!ct = !lattigo.rlwe.ciphertext
!decryptor = !lattigo.rlwe.decryptor
!encoder = !lattigo.ckks.encoder
!encryptor_pk = !lattigo.rlwe.encryptor<publicKey = true>
!evaluator = !lattigo.ckks.evaluator
!kgen = !lattigo.rlwe.key_generator
!param = !lattigo.ckks.parameter
!pk = !lattigo.rlwe.public_key
!sk = !lattigo.rlwe.secret_key
module attributes {scheme.ckks} {
  func.func @bootstrap(%bootstrapping_evaluator: !bootstrapping_evaluator, %evaluator: !evaluator, %param: !param, %encoder: !encoder, %ct: !ct {snabf.slot_period = 64 : i64}) -> !ct {
    %ct_0 = lattigo.ckks.bootstrap %bootstrapping_evaluator, %ct {snabf.boot_costs = {boot_costs = [{cost = 8.000000e+01 : f64, level = 1 : i64, n = 65536 : i64}, {cost = 4.000000e+01 : f64, level = 0 : i64, n = 32768 : i64}], down_cost = 1.000000e+01 : f64, downstream_bins = array<f64: 5.000000e+00, 5.000000e+00>, gadget_weights = array<f64: 1.000000e+00, 2.000000e+00>, key_variance = 1.8310546875E-4 : f64, layout_contract = "trace-periodic", layout_cost = 0.000000e+00 : f64, layout_verified = true, multiplicity = 1 : i64, target_n = 32768 : i64, up_cost = 2.000000e+01 : f64}, snabf.bootstrap_kernel = "periodic-n15-v1", snabf.ring_switch = {beta_pack = 1 : i64, down_cost = 1.000000e+01 : f64, downstream_penalty = 5.000000e+00 : f64, enabled = true, execution = "periodic-n15-v1", input_level = 1 : i64, input_variance = 0.000000e+00 : f64, layout_contract = "trace-periodic", layout_cost = 0.000000e+00 : f64, live_slots = 64 : i64, margin = 5.000000e+00 : f64, min_small_level = 0 : i64, one_up_cost = 2.000000e+01 : f64, output_variance = 5.000000e+00 : f64, penalty = 3.500000e+01 : f64, reason = "profitable", rs_variance = 5.000000e+00 : f64, savings = 4.000000e+01 : f64, small_level = 0 : i64, source_n = 65536 : i64, source_period = 64 : i64, target_n = 32768 : i64}, snabf_input_level = 1 : i64, snabf_live_slots = 64 : i64} : (!bootstrapping_evaluator, !ct) -> !ct
    return %ct_0 : !ct
  }
  func.func @bootstrap__configure() -> (!bootstrapping_evaluator, !evaluator, !param, !encoder, !encryptor_pk, !decryptor) {
    %param = lattigo.ckks.new_parameters_from_literal  <paramsLiteral = <logN = 16, Q = [1099512938497, 2148794369, 2150760449, 2150891521, 2151677953], P = [72057594038321153, 72057594040680449], logDefaultScale = 31>> : () -> !param
    %encoder = lattigo.ckks.new_encoder %param : (!param) -> !encoder
    %kgen = lattigo.rlwe.new_key_generator %param : (!param) -> !kgen
    %secretKey, %publicKey = lattigo.rlwe.gen_key_pair %kgen : (!kgen) -> (!sk, !pk)
    %encryptor = lattigo.rlwe.new_encryptor %param, %publicKey : (!param, !pk) -> !encryptor_pk
    %decryptor = lattigo.rlwe.new_decryptor %param, %secretKey : (!param, !sk) -> !decryptor
    %bootstrapping_param = lattigo.ckks.new_bootstrapping_parameters_from_literal %param <btParamsLiteral = <logN = 16>> : (!param) -> !bootstrapping_param
    %bootstrapping_eval_keys = lattigo.ckks.gen_evaluation_keys_bootstrapping %bootstrapping_param, %secretKey : (!bootstrapping_param, !sk) -> !bootstrapping_eval_keys
    %bootstrapping_evaluator = lattigo.ckks.new_bootstrapping_evaluator %bootstrapping_param, %bootstrapping_eval_keys : (!bootstrapping_param, !bootstrapping_eval_keys) -> !bootstrapping_evaluator
    %evaluator = lattigo.ckks.new_evaluator %param : (!param) -> !evaluator
    return %bootstrapping_evaluator, %evaluator, %param, %encoder, %encryptor, %decryptor : !bootstrapping_evaluator, !evaluator, !param, !encoder, !encryptor_pk, !decryptor
  }
}

