"builtin.module"() ({
  "func.func"() <{arg_attrs = [{}, {}, {}, {}, {snabf.slot_period = 64 : i64}], function_type = (!lattigo.ckks.bootstrapping_evaluator, !lattigo.ckks.evaluator, !lattigo.ckks.parameter, !lattigo.ckks.encoder, !lattigo.rlwe.ciphertext) -> !lattigo.rlwe.ciphertext, sym_name = "bootstrap"}> ({
  ^bb0(%arg0: !lattigo.ckks.bootstrapping_evaluator, %arg1: !lattigo.ckks.evaluator, %arg2: !lattigo.ckks.parameter, %arg3: !lattigo.ckks.encoder, %arg4: !lattigo.rlwe.ciphertext):
    %10 = "lattigo.ckks.bootstrap"(%arg0, %arg4) {snabf.boot_costs = {boot_costs = [{cost = 8.000000e+01 : f64, level = 1 : i64, n = 65536 : i64}, {cost = 4.000000e+01 : f64, level = 0 : i64, n = 32768 : i64}], down_cost = 1.000000e+01 : f64, downstream_bins = array<f64: 5.000000e+00, 5.000000e+00>, gadget_weights = array<f64: 1.000000e+00, 2.000000e+00>, key_variance = 1.8310546875E-4 : f64, layout_contract = "trace-periodic", layout_cost = 0.000000e+00 : f64, layout_verified = true, multiplicity = 1 : i64, target_n = 32768 : i64, up_cost = 2.000000e+01 : f64}, snabf.bootstrap_kernel = "periodic-n15-v1", snabf_input_level = 1 : i64, snabf_live_slots = 64 : i64} : (!lattigo.ckks.bootstrapping_evaluator, !lattigo.rlwe.ciphertext) -> !lattigo.rlwe.ciphertext
    "func.return"(%10) : (!lattigo.rlwe.ciphertext) -> ()
  }) : () -> ()
  "func.func"() <{function_type = () -> (!lattigo.ckks.bootstrapping_evaluator, !lattigo.ckks.evaluator, !lattigo.ckks.parameter, !lattigo.ckks.encoder, !lattigo.rlwe.encryptor<publicKey = true>, !lattigo.rlwe.decryptor), sym_name = "bootstrap__configure"}> ({
    %0 = "lattigo.ckks.new_parameters_from_literal"() <{paramsLiteral = #lattigo.ckks.parameters_literal<logN = 16, Q = [1099512938497, 2148794369, 2150760449, 2150891521, 2151677953], P = [72057594038321153, 72057594040680449], logDefaultScale = 31>}> : () -> !lattigo.ckks.parameter
    %1 = "lattigo.ckks.new_encoder"(%0) : (!lattigo.ckks.parameter) -> !lattigo.ckks.encoder
    %2 = "lattigo.rlwe.new_key_generator"(%0) : (!lattigo.ckks.parameter) -> !lattigo.rlwe.key_generator
    %3:2 = "lattigo.rlwe.gen_key_pair"(%2) : (!lattigo.rlwe.key_generator) -> (!lattigo.rlwe.secret_key, !lattigo.rlwe.public_key)
    %4 = "lattigo.rlwe.new_encryptor"(%0, %3#1) : (!lattigo.ckks.parameter, !lattigo.rlwe.public_key) -> !lattigo.rlwe.encryptor<publicKey = true>
    %5 = "lattigo.rlwe.new_decryptor"(%0, %3#0) : (!lattigo.ckks.parameter, !lattigo.rlwe.secret_key) -> !lattigo.rlwe.decryptor
    %6 = "lattigo.ckks.new_bootstrapping_parameters_from_literal"(%0) <{btParamsLiteral = #lattigo.ckks.bootstrapping_parameters_literal<logN = 16>}> : (!lattigo.ckks.parameter) -> !lattigo.ckks.bootstrapping_parameter
    %7 = "lattigo.ckks.gen_evaluation_keys_bootstrapping"(%6, %3#0) : (!lattigo.ckks.bootstrapping_parameter, !lattigo.rlwe.secret_key) -> !lattigo.ckks.bootstrapping_eval_keys
    %8 = "lattigo.ckks.new_bootstrapping_evaluator"(%6, %7) : (!lattigo.ckks.bootstrapping_parameter, !lattigo.ckks.bootstrapping_eval_keys) -> !lattigo.ckks.bootstrapping_evaluator
    %9 = "lattigo.ckks.new_evaluator"(%0) : (!lattigo.ckks.parameter) -> !lattigo.ckks.evaluator
    "func.return"(%8, %9, %0, %1, %4, %5) : (!lattigo.ckks.bootstrapping_evaluator, !lattigo.ckks.evaluator, !lattigo.ckks.parameter, !lattigo.ckks.encoder, !lattigo.rlwe.encryptor<publicKey = true>, !lattigo.rlwe.decryptor) -> ()
  }) : () -> ()
}) {scheme.ckks} : () -> ()
