package comparison
import (
direct "snabf.local/compiler/build/pass4-ab-release-20261119/run.POAcXfhz/control/direct"
legacy "snabf.local/compiler/build/pass4-ab-release-20261119/run.POAcXfhz/control/legacy"
)
var newDirect = direct.New
var legacyConfigure = legacy.Linear_silu_linear__configure
var legacyPrepare = legacy.Linear_silu_linear__preprocessing
var legacyEval = legacy.Linear_silu_linear__preprocessed
