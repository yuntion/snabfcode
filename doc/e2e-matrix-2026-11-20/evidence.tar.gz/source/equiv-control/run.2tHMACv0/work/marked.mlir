"builtin.module"() ({
  "func.func"() <{arg_attrs = [{secret.secret}], function_type = (tensor<4xf32>) -> tensor<4xf32>, sym_name = "linear_silu_linear"}> ({
  ^bb0(%arg0: tensor<4xf32>):
    %0 = "arith.constant"() <{value = dense<[[5.000000e-01, -2.500000e-01, 1.250000e-01, 0.000000e+00], [0.000000e+00, 3.750000e-01, 1.250000e-01, 2.500000e-01], [-2.500000e-01, 0.000000e+00, 5.000000e-01, 1.250000e-01], [1.250000e-01, -1.250000e-01, 2.500000e-01, 2.500000e-01]]> : tensor<4x4xf32>}> : () -> tensor<4x4xf32>
    %1 = "arith.constant"() <{value = dense<[[2.500000e-01, 5.000000e-01, 0.000000e+00, -1.250000e-01], [3.750000e-01, -1.250000e-01, 2.500000e-01, 0.000000e+00], [0.000000e+00, 2.500000e-01, -2.500000e-01, 5.000000e-01], [-1.250000e-01, 0.000000e+00, 5.000000e-01, 2.500000e-01]]> : tensor<4x4xf32>}> : () -> tensor<4x4xf32>
    %2 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
    %3 = "arith.constant"() <{value = 1.000000e+00 : f32}> : () -> f32
    %4 = "tensor.empty"() : () -> tensor<4xf32>
    %5 = "linalg.fill"(%2, %4) <{operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg9: f32, %arg10: f32):
      "linalg.yield"(%arg9) : (f32) -> ()
    }) : (f32, tensor<4xf32>) -> tensor<4xf32>
    %6 = "linalg.matvec"(%0, %arg0, %5) <{operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg6: f32, %arg7: f32, %arg8: f32):
      %16 = "arith.mulf"(%arg6, %arg7) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %17 = "arith.addf"(%arg8, %16) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%17) : (f32) -> ()
    }) {linalg.memoized_indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d1)>, affine_map<(d0, d1) -> (d0)>]} : (tensor<4x4xf32>, tensor<4xf32>, tensor<4xf32>) -> tensor<4xf32>
    %7 = "linalg.generic"(%6, %4) <{indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = [#linalg.iterator_type<parallel>], operandSegmentSizes = array<i32: 1, 1>}> ({
    ^bb0(%arg4: f32, %arg5: f32):
      %11 = "arith.negf"(%arg4) <{fastmath = #arith.fastmath<none>}> : (f32) -> f32
      %12 = "math.exp"(%11) <{fastmath = #arith.fastmath<none>}> : (f32) -> f32
      %13 = "arith.addf"(%12, %3) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %14 = "arith.divf"(%3, %13) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %15 = "arith.mulf"(%arg4, %14) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%15) : (f32) -> ()
    }) {domain_lower = -1.000000e+00 : f64, domain_upper = 1.000000e+00 : f64} : (tensor<4xf32>, tensor<4xf32>) -> tensor<4xf32>
    %8 = "linalg.matvec"(%1, %7, %5) <{operandSegmentSizes = array<i32: 2, 1>}> ({
    ^bb0(%arg1: f32, %arg2: f32, %arg3: f32):
      %9 = "arith.mulf"(%arg1, %arg2) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      %10 = "arith.addf"(%arg3, %9) <{fastmath = #arith.fastmath<none>}> : (f32, f32) -> f32
      "linalg.yield"(%10) : (f32) -> ()
    }) {linalg.memoized_indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d1)>, affine_map<(d0, d1) -> (d0)>]} : (tensor<4x4xf32>, tensor<4xf32>, tensor<4xf32>) -> tensor<4xf32>
    "func.return"(%8) : (tensor<4xf32>) -> ()
  }) : () -> ()
}) {snabf.activation_sources = [{function = "linear_silu_linear", semantics = "silu"}]} : () -> ()
