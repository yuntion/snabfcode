package pass2_test
import (
"testing"
p0 "snabf.local/compiler/build/pass1-revision/run.GIOCVvjG/pass2/residual/economy"
p1 "snabf.local/compiler/build/pass1-revision/run.GIOCVvjG/pass2/residual/precision"
)
func Test_residual(t *testing.T) {
  dir := "../residual"
  experiment(t, dir, 64, []arm{
    newArm(t, dir, "economy", p0.Linear_silu_linear__configure, p0.Linear_silu_linear__preprocessing, p0.Linear_silu_linear__preprocessed, p0.Linear_silu_linear__encrypt__arg0, p0.Linear_silu_linear__decrypt__result0),
    newArm(t, dir, "precision", p1.Linear_silu_linear__configure, p1.Linear_silu_linear__preprocessing, p1.Linear_silu_linear__preprocessed, p1.Linear_silu_linear__encrypt__arg0, p1.Linear_silu_linear__decrypt__result0),
  })
}
